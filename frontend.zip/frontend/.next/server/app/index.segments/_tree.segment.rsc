:HL["/_next/static/chunks/a239bbfa00ce9285.css","style"]
0:{"buildId":"QFRGNJwA1TVzNdc_Lh0xL","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
