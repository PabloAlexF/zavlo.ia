1:"$Sreact.fragment"
2:I[32035,["/_next/static/chunks/6e9ac5b86215ad1c.js","/_next/static/chunks/4f12ca97cd3387c8.js"],"default"]
3:I[91168,["/_next/static/chunks/6e9ac5b86215ad1c.js","/_next/static/chunks/4f12ca97cd3387c8.js"],"default"]
0:{"buildId":"QFRGNJwA1TVzNdc_Lh0xL","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
