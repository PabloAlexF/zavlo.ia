globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/f7281c1aca924357.js",
    "static/chunks/8c648a58626f342a.js",
    "static/chunks/6b8c38cc1ceab5fd.js",
    "static/chunks/6c36f1b3dd877bd3.js",
    "static/chunks/929471bc05e5ed12.js",
    "static/chunks/turbopack-df1d3b29f8b4fd5e.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];