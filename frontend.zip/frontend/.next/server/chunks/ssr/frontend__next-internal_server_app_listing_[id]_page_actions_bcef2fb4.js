module.exports=[46877,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_listing_%5Bid%5D_page_actions_bcef2fb4.js.map