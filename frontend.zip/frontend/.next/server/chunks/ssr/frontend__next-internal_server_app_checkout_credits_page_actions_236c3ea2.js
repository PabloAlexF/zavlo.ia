module.exports=[84425,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_checkout_credits_page_actions_236c3ea2.js.map