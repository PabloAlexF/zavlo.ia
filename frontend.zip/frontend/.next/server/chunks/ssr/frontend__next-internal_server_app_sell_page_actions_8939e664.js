module.exports=[60859,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_sell_page_actions_8939e664.js.map