module.exports=[95501,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_plans_page_actions_e311984e.js.map